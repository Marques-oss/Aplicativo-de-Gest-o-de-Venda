// Testes automáticos da lógica (cálculos, validações e formatação).
// Rodar com:  npm test

import assert from 'node:assert/strict';
import {
  calcularSubtotal,
  calcularTotal,
  produtosMaisVendidos,
  resumoVendas,
} from '../src/utils/calculos.js';
import { formatarDataHora, formatarMoeda, iniciais, precoParaTexto } from '../src/utils/format.js';
import {
  converterInteiro,
  converterPreco,
  validarProduto,
  validarQuantidadeVenda,
  validarUsuario,
} from '../src/utils/validacao.js';

let aprovados = 0;
function teste(nome, funcao) {
  try {
    funcao();
    aprovados += 1;
    console.log(`  ✓ ${nome}`);
  } catch (erro) {
    console.error(`  ✗ ${nome}\n    ${erro.message}`);
    process.exitCode = 1;
  }
}

console.log('\nCálculos');
teste('subtotal: 2 × R$ 18,90 = R$ 37,80', () => {
  assert.equal(calcularSubtotal(18.9, 2), 37.8);
});
teste('subtotal: 3 × R$ 2,50 = R$ 7,50', () => {
  assert.equal(calcularSubtotal(2.5, 3), 7.5);
});
teste('teste de conferência da atividade: 2 cadernos + 3 canetas = R$ 45,30', () => {
  const total = calcularTotal([
    { precoUnitario: 18.9, quantidade: 2 },
    { precoUnitario: 2.5, quantidade: 3 },
  ]);
  assert.equal(total, 45.3);
});
teste('não acumula erro de ponto flutuante (0,10 × 3 = 0,30)', () => {
  assert.equal(calcularTotal([{ precoUnitario: 0.1, quantidade: 3 }]), 0.3);
});
teste('total de lista vazia é zero', () => {
  assert.equal(calcularTotal([]), 0);
});

const vendasExemplo = [
  {
    id: 'V-0002',
    total: 89.9,
    itens: [{ produtoId: 'p4', nome: 'Mochila básica', precoUnitario: 89.9, quantidade: 1, subtotal: 89.9 }],
  },
  {
    id: 'V-0001',
    total: 45.3,
    itens: [
      { produtoId: 'p1', nome: 'Caderno universitário', precoUnitario: 18.9, quantidade: 2, subtotal: 37.8 },
      { produtoId: 'p2', nome: 'Caneta azul', precoUnitario: 2.5, quantidade: 3, subtotal: 7.5 },
    ],
  },
];

console.log('\nRelatórios');
teste('resumo: quantidade, valor total, itens e ticket médio', () => {
  const r = resumoVendas(vendasExemplo);
  assert.equal(r.quantidadeVendas, 2);
  assert.equal(r.valorTotal, 135.2);
  assert.equal(r.itensVendidos, 6);
  assert.equal(r.ticketMedio, 67.6);
});
teste('resumo sem vendas retorna zeros', () => {
  const r = resumoVendas([]);
  assert.deepEqual(r, { quantidadeVendas: 0, valorTotal: 0, itensVendidos: 0, ticketMedio: 0 });
});
teste('ranking por quantidade: caneta (3) vem primeiro', () => {
  const ranking = produtosMaisVendidos(vendasExemplo, 'quantidade');
  assert.equal(ranking[0].nome, 'Caneta azul');
  assert.equal(ranking[0].quantidade, 3);
});
teste('ranking por valor: mochila (R$ 89,90) vem primeiro', () => {
  const ranking = produtosMaisVendidos(vendasExemplo, 'valor');
  assert.equal(ranking[0].nome, 'Mochila básica');
  assert.equal(ranking[0].valor, 89.9);
});
teste('ranking soma o mesmo produto em vendas diferentes', () => {
  const duas = [
    { total: 5, itens: [{ produtoId: 'p2', nome: 'Caneta azul', precoUnitario: 2.5, quantidade: 2, subtotal: 5 }] },
    { total: 2.5, itens: [{ produtoId: 'p2', nome: 'Caneta azul', precoUnitario: 2.5, quantidade: 1, subtotal: 2.5 }] },
  ];
  const ranking = produtosMaisVendidos(duas);
  assert.equal(ranking.length, 1);
  assert.equal(ranking[0].quantidade, 3);
  assert.equal(ranking[0].valor, 7.5);
});

console.log('\nFormatação');
teste('formatarMoeda', () => {
  assert.equal(formatarMoeda(45.3), 'R$ 45,30');
  assert.equal(formatarMoeda(0), 'R$ 0,00');
  assert.equal(formatarMoeda(1234.5), 'R$ 1.234,50');
  assert.equal(formatarMoeda(1000000), 'R$ 1.000.000,00');
});
teste('precoParaTexto', () => {
  assert.equal(precoParaTexto(18.9), '18,90');
});
teste('formatarDataHora com data inválida', () => {
  assert.equal(formatarDataHora('lixo'), '-');
});
teste('iniciais', () => {
  assert.equal(iniciais('Maria Souza'), 'MS');
  assert.equal(iniciais('João'), 'J');
  assert.equal(iniciais('  '), '?');
});

console.log('\nConversão de números');
teste('converterPreco aceita vírgula, ponto e milhar', () => {
  assert.equal(converterPreco('18,90'), 18.9);
  assert.equal(converterPreco('18.90'), 18.9);
  assert.equal(converterPreco('1.234,56'), 1234.56);
  assert.equal(converterPreco('R$ 5,00'), 5);
});
teste('converterPreco rejeita texto e vazio', () => {
  assert.ok(Number.isNaN(converterPreco('abc')));
  assert.ok(Number.isNaN(converterPreco('')));
  assert.ok(Number.isNaN(converterPreco('1,2,3')));
});
teste('converterInteiro', () => {
  assert.equal(converterInteiro('10'), 10);
  assert.equal(converterInteiro('-3'), -3);
  assert.ok(Number.isNaN(converterInteiro('1.5')));
  assert.ok(Number.isNaN(converterInteiro('abc')));
  assert.ok(Number.isNaN(converterInteiro('')));
});

console.log('\nValidação de produto');
const existentes = [{ id: 'p1', codigo: 'CAD-001' }];
const produtoOk = { nome: 'Lápis', codigo: 'LAP-001', categoria: 'Papelaria', preco: '1,50', estoque: '30' };
teste('produto válido passa', () => {
  const r = validarProduto(produtoOk, existentes);
  assert.equal(r.valido, true);
  assert.deepEqual(r.valores, { nome: 'Lápis', codigo: 'LAP-001', categoria: 'Papelaria', preco: 1.5, estoque: 30 });
});
teste('sem nome é inválido', () => {
  const r = validarProduto({ ...produtoOk, nome: '   ' }, existentes);
  assert.equal(r.valido, false);
  assert.ok(r.erros.nome);
});
teste('preço negativo é inválido', () => {
  const r = validarProduto({ ...produtoOk, preco: '-5' }, existentes);
  assert.equal(r.valido, false);
  assert.match(r.erros.preco, /negativo/);
});
teste('preço zero, vazio, texto e 3 casas decimais são inválidos', () => {
  assert.ok(validarProduto({ ...produtoOk, preco: '0' }, existentes).erros.preco);
  assert.ok(validarProduto({ ...produtoOk, preco: '' }, existentes).erros.preco);
  assert.ok(validarProduto({ ...produtoOk, preco: 'abc' }, existentes).erros.preco);
  assert.ok(validarProduto({ ...produtoOk, preco: '1,999' }, existentes).erros.preco);
});
teste('estoque negativo ou decimal é inválido; zero é permitido', () => {
  assert.ok(validarProduto({ ...produtoOk, estoque: '-1' }, existentes).erros.estoque);
  assert.ok(validarProduto({ ...produtoOk, estoque: '2.5' }, existentes).erros.estoque);
  assert.equal(validarProduto({ ...produtoOk, estoque: '0' }, existentes).valido, true);
});
teste('código repetido é inválido, mas editar o próprio produto é permitido', () => {
  assert.ok(validarProduto({ ...produtoOk, codigo: 'cad-001' }, existentes).erros.codigo);
  assert.equal(validarProduto({ ...produtoOk, codigo: 'CAD-001' }, existentes, 'p1').valido, true);
});

console.log('\nValidação de usuário');
const usuariosExistentes = [{ id: 'u1', email: 'maria@exemplo.com' }];
teste('usuário válido passa', () => {
  const r = validarUsuario({ nome: 'Ana', email: 'ana@exemplo.com', perfil: 'Vendedor' }, usuariosExistentes);
  assert.equal(r.valido, true);
});
teste('e-mail inválido e perfil ausente são rejeitados', () => {
  const r = validarUsuario({ nome: 'Ana', email: 'ana@', perfil: '' }, usuariosExistentes);
  assert.equal(r.valido, false);
  assert.ok(r.erros.email);
  assert.ok(r.erros.perfil);
});
teste('e-mail repetido é rejeitado', () => {
  const r = validarUsuario({ nome: 'Outra', email: 'MARIA@exemplo.com', perfil: 'Vendedor' }, usuariosExistentes);
  assert.ok(r.erros.email);
});

console.log('\nValidação de quantidade na venda (estoque 10)');
teste('quantidade zero, negativa, decimal e texto são recusadas', () => {
  assert.equal(validarQuantidadeVenda('0', 10).ok, false);
  assert.equal(validarQuantidadeVenda('-2', 10).ok, false);
  assert.equal(validarQuantidadeVenda('1.5', 10).ok, false);
  assert.equal(validarQuantidadeVenda('abc', 10).ok, false);
  assert.equal(validarQuantidadeVenda('', 10).ok, false);
});
teste('acima do estoque é recusada; igual ao estoque é aceita', () => {
  const acima = validarQuantidadeVenda('11', 10);
  assert.equal(acima.ok, false);
  assert.match(acima.erro, /Estoque insuficiente/);
  assert.equal(validarQuantidadeVenda('10', 10).ok, true);
  assert.equal(validarQuantidadeVenda('3', 10).valor, 3);
});

console.log(`\n${aprovados} testes aprovados.${process.exitCode ? ' HÁ FALHAS!' : ''}\n`);
