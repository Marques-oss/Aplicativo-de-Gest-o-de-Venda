# Gestão de Vendas Mobile

## Sobre o projeto
Aplicativo acadêmico para simular a gestão de uma pequena loja: cadastro de produtos e usuários, registro de **vendas fictícias** e relatórios calculados a partir das vendas registradas.

Projeto da disciplina **Programação para Dispositivos Móveis II** (ADS — 5º semestre).

> **Aviso:** é um protótipo demonstrativo. Não processa pagamentos reais, não emite documentos fiscais, não guarda senhas e não tem autenticação de produção. Toda venda é fictícia.

## Tecnologias
- React Native
- Expo (SDK 54) com Expo Router (navegação por arquivos)
- JavaScript
- AsyncStorage (persistência local)

## Funcionalidades

**Painel inicial**
- Nome do app, atalhos para Produtos, Usuários, Vendas e Relatórios
- Indicadores: quantidade de produtos, número de vendas e valor total vendido
- Botão para restaurar os dados de demonstração

**Produtos**
- Cadastro com nome, código, categoria, preço e estoque
- Listagem com busca, tela de detalhes, edição e exclusão (com confirmação)
- Validações: campos obrigatórios, preço negativo/zero/inválido, estoque inválido e código repetido

**Usuários**
- Cadastro com nome, e-mail e perfil (Administrador ou Vendedor)
- Listagem, detalhes, edição e exclusão (com confirmação)
- Validações: campos obrigatórios, formato do e-mail e e-mail repetido
- Sem senhas e sem login real

**Vendas fictícias**
- Seleção de um ou mais produtos e quantidade de cada item
- Subtotal por item (preço × quantidade) e total calculados automaticamente
- Etapa de revisão antes de confirmar
- Registro com identificador (V-0001, V-0002...), data/hora, itens, quantidades e total
- Confirmação visual após registrar
- Controle de estoque: a venda baixa o estoque e nunca permite estoque negativo

**Relatórios**
- Resumo: vendas registradas, itens vendidos, valor total e ticket médio
- Produtos mais vendidos, ordenados por quantidade ou por valor
- Histórico de vendas (identificador, data e total)
- Todos os números são calculados a partir das vendas registradas

## Como executar

Pré-requisitos: [Node.js](https://nodejs.org) (versão LTS) e o aplicativo **Expo Go** no celular (ou um emulador Android/iOS).

1. Clone este repositório e entre na pasta do projeto:
   ```bash
   git clone https://github.com/SEU-USUARIO/gestao-vendas-mobile.git
   cd gestao-vendas-mobile
   ```
2. Instale as dependências:
   ```bash
   npm install
   ```
3. Se o npm ou o Expo avisar que alguma versão não combina com o SDK, ajuste automaticamente:
   ```bash
   npx expo install --fix
   ```
4. Inicie o projeto:
   ```bash
   npx expo start
   ```
5. Abra no celular escaneando o QR Code com o **Expo Go** (celular e computador na mesma rede Wi-Fi), ou pressione `a` para o emulador Android, `i` para o simulador iOS ou `w` para abrir no navegador.

> **O Expo Go avisou que o projeto é de outra versão (SDK)?** O Expo Go da loja só abre a versão de SDK mais recente. Atualize o projeto com:
> ```bash
> npx expo install expo@latest
> npx expo install --fix
> ```

## Como testar

### Testes automáticos da lógica
```bash
npm test
```
Verifica cálculos de subtotal e total (inclusive o teste de conferência: 2 cadernos a R$ 18,90 + 3 canetas a R$ 2,50 = **R$ 45,30**), relatórios, formatação e todas as validações.

### Roteiro de testes manuais (no app)
| # | Teste | Resultado esperado |
|---|-------|--------------------|
| 1 | Cadastrar um produto válido | Aparece na listagem com mensagem de sucesso |
| 2 | Salvar produto sem nome ou com preço negativo | Mensagem de erro no campo; produto não é salvo |
| 3 | Cadastrar um usuário | Aparece na lista de usuários |
| 4 | Registrar venda com mais de um produto (2 cadernos + 3 canetas) | Total de R$ 45,30 |
| 5 | Quantidade zero, negativa ou acima do estoque | Mensagem de erro; a venda não avança |
| 6 | Confirmar a venda | Aparece no histórico e o estoque diminui |
| 7 | Abrir Relatórios após a venda | Resumo, ranking e histórico atualizados |
| 8 | Abrir Relatórios/Vendas sem nenhuma venda | Mensagem de lista vazia (use "Restaurar dados") |
| 9 | Fechar e reabrir o app | Os dados continuam salvos |
| 10 | Seguir este README em outra máquina | O app abre normalmente |

## Estrutura do projeto
```
app/                      Telas (Expo Router: cada arquivo é uma rota)
  index.js                Painel inicial
  produtos/               Lista, formulário e detalhes de produtos
  usuarios/               Lista, formulário e detalhes de usuários
  vendas/                 Histórico, nova venda e detalhes da venda
  relatorios.js           Relatórios
src/
  components/             Componentes reutilizáveis (botão, campo, cartão...)
  context/                Estado global (dados) e mensagens rápidas
  data/                   Dados de demonstração
  utils/                  Cálculos, validações e formatação
  theme.js                Cores e tamanhos
scripts/
  testar-calculos.mjs     Testes automáticos da lógica
```

## Dados de demonstração
O app inicia com 4 produtos (Caderno universitário, Caneta azul, Garrafa térmica e Mochila básica) e 2 usuários fictícios. O cadastro continua funcionando normalmente.

## Integrantes
- Nome completo — responsabilidade principal
- Nome completo — responsabilidade principal

## Capturas de tela
_Adicione aqui capturas de tela ou um link para um vídeo curto de demonstração._

## Limitações conhecidas
- **Armazenamento:** os dados são salvos **localmente no aparelho** (AsyncStorage). Eles continuam existindo ao fechar e reabrir o app, mas **não são sincronizados entre dispositivos** e são apagados se o app for desinstalado ou se os dados do navegador forem limpos. Não há API nem banco de dados remoto.
- **Autenticação:** não há login. Os usuários são apenas registros de demonstração, sem senha.
- **Vendas:** são fictícias. Não há pagamento, Pix, cartão, TEF nem emissão fiscal.
- **Produtos excluídos:** vendas antigas continuam no histórico com o nome e o preço da época da venda.
- **Relatórios:** usam cartões, barras e listas simples (sem gráficos avançados nem exportação para Excel/PDF).
