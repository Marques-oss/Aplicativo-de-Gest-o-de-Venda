import React, { useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Chips from '../../src/components/Chips';
import EmptyState from '../../src/components/EmptyState';
import Field from '../../src/components/Field';
import Screen from '../../src/components/Screen';
import useParamId from '../../src/hooks/useParamId';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { voltar } from '../../src/utils/interacao';
import { PERFIS, validarUsuario } from '../../src/utils/validacao';
import { colors, fonts, radius } from '../../src/theme';

function FormularioUsuario({ id }) {
  const router = useRouter();
  const { usuarios, salvarUsuario } = useStore();
  const { mostrar } = useToast();

  const existente = id ? usuarios.find((u) => u.id === id) : undefined;

  const [campos, setCampos] = useState({
    nome: existente ? existente.nome : '',
    email: existente ? existente.email : '',
    perfil: existente ? existente.perfil : '',
  });
  const [erros, setErros] = useState({});

  if (id && !existente) {
    return (
      <Screen>
        <EmptyState
          titulo="Usuário não encontrado"
          mensagem="Ele pode ter sido excluído."
          acaoTitulo="Voltar para usuários"
          onAcao={() => router.replace('/usuarios')}
        />
      </Screen>
    );
  }

  const alterar = (campo) => (valor) => {
    setCampos((atual) => ({ ...atual, [campo]: valor }));
    if (erros[campo]) setErros((atual) => ({ ...atual, [campo]: undefined }));
  };

  const salvar = () => {
    const resultado = validarUsuario(campos, usuarios, id);
    if (!resultado.valido) {
      setErros(resultado.erros);
      mostrar('Corrija os campos destacados.', 'erro');
      return;
    }
    salvarUsuario(resultado.valores, id);
    mostrar(id ? 'Usuário atualizado com sucesso.' : 'Usuário cadastrado com sucesso.');
    voltar(router, '/usuarios');
  };

  return (
    <Screen>
      <Stack.Screen options={{ title: id ? 'Editar usuário' : 'Novo usuário' }} />

      <Field
        rotulo="Nome completo"
        placeholder="Ex.: Maria Souza"
        value={campos.nome}
        onChangeText={alterar('nome')}
        autoCapitalize="words"
        erro={erros.nome}
      />
      <Field
        rotulo="E-mail"
        placeholder="Ex.: maria@exemplo.com"
        value={campos.email}
        onChangeText={alterar('email')}
        keyboardType="email-address"
        autoCapitalize="none"
        autoCorrect={false}
        erro={erros.email}
      />
      <Chips
        rotulo="Perfil / função"
        opcoes={PERFIS}
        valor={campos.perfil}
        onChange={alterar('perfil')}
        erro={erros.perfil}
      />

      <View style={styles.aviso}>
        <Text style={styles.avisoTexto}>
          Não informe senhas reais. Este app é uma demonstração e não possui autenticação de
          produção.
        </Text>
      </View>

      <View style={styles.acoes}>
        <Button titulo="Cancelar" variante="secundario" style={styles.botao} onPress={() => voltar(router, '/usuarios')} />
        <Button titulo="Salvar" style={styles.botao} onPress={salvar} />
      </View>
    </Screen>
  );
}

export default function UsuarioForm() {
  const id = useParamId();
  return <FormularioUsuario id={id} key={id || 'novo'} />;
}

const styles = StyleSheet.create({
  aviso: {
    backgroundColor: colors.avisoClaro,
    borderRadius: radius.md,
    padding: 12,
    marginBottom: 16,
  },
  avisoTexto: { color: colors.aviso, fontSize: fonts.pequena, fontWeight: '600' },
  acoes: { flexDirection: 'row', gap: 12 },
  botao: { flex: 1 },
});
