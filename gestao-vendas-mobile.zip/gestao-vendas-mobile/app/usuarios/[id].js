import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import Info from '../../src/components/Info';
import Screen from '../../src/components/Screen';
import useParamId from '../../src/hooks/useParamId';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { confirmar, voltar } from '../../src/utils/interacao';

export default function DetalheUsuario() {
  const id = useParamId();
  const router = useRouter();
  const { usuarios, excluirUsuario } = useStore();
  const { mostrar } = useToast();

  const usuario = usuarios.find((u) => u.id === id);

  if (!usuario) {
    return (
      <Screen>
        <EmptyState
          titulo="Usuário não encontrado"
          mensagem="Ele pode ter sido excluído."
          acaoTitulo="Voltar para usuários"
          onAcao={() => router.replace('/usuarios')}
        />
      </Screen>
    );
  }

  const aoExcluir = () => {
    confirmar(
      'Excluir usuário',
      `Deseja excluir "${usuario.nome}"? Esta ação não pode ser desfeita.`,
      () => {
        voltar(router, '/usuarios');
        excluirUsuario(usuario.id);
        mostrar(`Usuário "${usuario.nome}" excluído.`);
      }
    );
  };

  return (
    <Screen>
      <Card>
        <Info rotulo="Nome" valor={usuario.nome} />
        <Info rotulo="E-mail" valor={usuario.email} />
        <Info rotulo="Perfil / função" valor={usuario.perfil} />
      </Card>

      <View style={styles.acoes}>
        <Button
          titulo="Editar"
          variante="secundario"
          style={styles.botao}
          onPress={() => router.push({ pathname: '/usuarios/form', params: { id: usuario.id } })}
        />
        <Button titulo="Excluir" variante="perigoSuave" style={styles.botao} onPress={aoExcluir} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  acoes: { flexDirection: 'row', gap: 12 },
  botao: { flex: 1 },
});
