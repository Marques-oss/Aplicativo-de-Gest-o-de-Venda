import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import RodapeFixo from '../../src/components/RodapeFixo';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { iniciais } from '../../src/utils/format';
import { confirmar } from '../../src/utils/interacao';
import { colors, fonts, spacing } from '../../src/theme';

export default function ListaUsuarios() {
  const router = useRouter();
  const { usuarios, excluirUsuario } = useStore();
  const { mostrar } = useToast();

  const aoExcluir = (usuario) => {
    confirmar(
      'Excluir usuário',
      `Deseja excluir "${usuario.nome}"? Esta ação não pode ser desfeita.`,
      () => {
        excluirUsuario(usuario.id);
        mostrar(`Usuário "${usuario.nome}" excluído.`);
      }
    );
  };

  return (
    <View style={styles.tela}>
      <FlatList
        data={usuarios}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.lista}
        ListHeaderComponent={
          <Text style={styles.aviso}>
            Usuários de demonstração. O app não guarda senhas nem tem autenticação real.
          </Text>
        }
        ListEmptyComponent={
          <EmptyState
            icone="👥"
            titulo="Nenhum usuário cadastrado"
            mensagem="Cadastre um usuário de demonstração."
            acaoTitulo="Cadastrar usuário"
            onAcao={() => router.push('/usuarios/form')}
          />
        }
        renderItem={({ item }) => (
          <Card>
            <Pressable
              onPress={() => router.push(`/usuarios/${item.id}`)}
              accessibilityRole="button"
              accessibilityLabel={`Ver detalhes de ${item.nome}`}
              style={styles.linhaPrincipal}
            >
              <View style={styles.avatar}>
                <Text style={styles.avatarTexto}>{iniciais(item.nome)}</Text>
              </View>
              <View style={styles.dados}>
                <Text style={styles.nome}>{item.nome}</Text>
                <Text style={styles.meta}>{item.email}</Text>
                <Text style={styles.perfil}>{item.perfil}</Text>
              </View>
            </Pressable>
            <View style={styles.acoes}>
              <Button
                titulo="Editar"
                variante="secundario"
                style={styles.botaoAcao}
                acessibilidadeLabel={`Editar ${item.nome}`}
                onPress={() => router.push({ pathname: '/usuarios/form', params: { id: item.id } })}
              />
              <Button
                titulo="Excluir"
                variante="perigoSuave"
                style={styles.botaoAcao}
                acessibilidadeLabel={`Excluir ${item.nome}`}
                onPress={() => aoExcluir(item)}
              />
            </View>
          </Card>
        )}
      />

      <RodapeFixo>
        <Button titulo="＋ Novo usuário" onPress={() => router.push('/usuarios/form')} />
      </RodapeFixo>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: colors.fundo },
  lista: { padding: spacing.md },
  aviso: { fontSize: fonts.pequena, color: colors.textoSuave, marginBottom: 12 },
  linhaPrincipal: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: colors.primariaClara,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarTexto: { color: colors.primaria, fontWeight: '800', fontSize: fonts.normal },
  dados: { flex: 1 },
  nome: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  meta: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2 },
  perfil: { fontSize: fonts.pequena, color: colors.primaria, fontWeight: '700', marginTop: 2 },
  acoes: { flexDirection: 'row', gap: 10, marginTop: 12 },
  botaoAcao: { flex: 1 },
});
