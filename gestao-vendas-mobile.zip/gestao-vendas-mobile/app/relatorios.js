import React, { useMemo, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Card from '../src/components/Card';
import Chips from '../src/components/Chips';
import EmptyState from '../src/components/EmptyState';
import Screen from '../src/components/Screen';
import StatCard from '../src/components/StatCard';
import { useStore } from '../src/context/StoreContext';
import { produtosMaisVendidos, resumoVendas } from '../src/utils/calculos';
import { formatarDataHora, formatarMoeda } from '../src/utils/format';
import { colors, fonts, radius, spacing } from '../src/theme';

const CRITERIOS = ['Quantidade', 'Valor'];

export default function Relatorios() {
  const router = useRouter();
  const { vendas } = useStore();
  const [criterio, setCriterio] = useState('Quantidade');

  // Tudo abaixo é calculado a partir das vendas registradas no app.
  const resumo = useMemo(() => resumoVendas(vendas), [vendas]);
  const ranking = useMemo(
    () => produtosMaisVendidos(vendas, criterio === 'Valor' ? 'valor' : 'quantidade'),
    [vendas, criterio]
  );

  if (vendas.length === 0) {
    return (
      <Screen>
        <EmptyState
          icone="📊"
          titulo="Ainda não há dados"
          mensagem="Registre uma venda fictícia para ver o resumo, o ranking e o histórico."
          acaoTitulo="Registrar venda"
          onAcao={() => router.push('/vendas/nova')}
        />
      </Screen>
    );
  }

  const maior = ranking.length > 0 ? (criterio === 'Valor' ? ranking[0].valor : ranking[0].quantidade) : 0;

  return (
    <Screen>
      <Text style={styles.secao}>Resumo de vendas</Text>
      <View style={styles.linhaStats}>
        <StatCard rotulo="Vendas registradas" valor={String(resumo.quantidadeVendas)} />
        <StatCard rotulo="Itens vendidos" valor={String(resumo.itensVendidos)} />
      </View>
      <View style={styles.linhaStats}>
        <StatCard rotulo="Valor total vendido" valor={formatarMoeda(resumo.valorTotal)} />
        <StatCard rotulo="Ticket médio" valor={formatarMoeda(resumo.ticketMedio)} />
      </View>

      <Text style={[styles.secao, styles.espacoSecao]}>Produtos mais vendidos</Text>
      <Chips rotulo="Ordenar por" opcoes={CRITERIOS} valor={criterio} onChange={setCriterio} />
      {ranking.map((produto, indice) => {
        const valorBarra = criterio === 'Valor' ? produto.valor : produto.quantidade;
        const largura = maior > 0 ? Math.max(4, (valorBarra / maior) * 100) : 0;
        return (
          <Card key={produto.produtoId}>
            <View style={styles.linhaRanking}>
              <Text style={styles.posicao}>{indice + 1}º</Text>
              <View style={styles.dadosRanking}>
                <Text style={styles.nome}>{produto.nome}</Text>
                <Text style={styles.meta}>
                  {produto.quantidade} un. • {formatarMoeda(produto.valor)}
                </Text>
              </View>
            </View>
            <View style={styles.trilho}>
              <View style={[styles.barra, { width: `${largura}%` }]} />
            </View>
          </Card>
        );
      })}

      <Text style={[styles.secao, styles.espacoSecao]}>Histórico de vendas</Text>
      {vendas.map((venda) => (
        <Pressable
          key={venda.id}
          onPress={() => router.push(`/vendas/${venda.id}`)}
          accessibilityRole="button"
          accessibilityLabel={`Venda ${venda.id}, ${formatarMoeda(venda.total)}. Ver detalhes`}
        >
          <Card>
            <View style={styles.linhaHistorico}>
              <View>
                <Text style={styles.nome}>{venda.id}</Text>
                <Text style={styles.meta}>{formatarDataHora(venda.dataHora)}</Text>
              </View>
              <Text style={styles.total}>{formatarMoeda(venda.total)}</Text>
            </View>
          </Card>
        </Pressable>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  secao: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto, marginBottom: 10 },
  espacoSecao: { marginTop: spacing.lg },
  linhaStats: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  linhaRanking: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  posicao: { fontSize: fonts.titulo, fontWeight: '800', color: colors.primaria, minWidth: 40 },
  dadosRanking: { flex: 1 },
  nome: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  meta: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2 },
  trilho: {
    height: 8,
    borderRadius: radius.sm,
    backgroundColor: colors.primariaClara,
    marginTop: 10,
    overflow: 'hidden',
  },
  barra: { height: 8, borderRadius: radius.sm, backgroundColor: colors.primaria },
  linhaHistorico: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  total: { fontSize: fonts.subtitulo, fontWeight: '800', color: colors.primaria },
});
