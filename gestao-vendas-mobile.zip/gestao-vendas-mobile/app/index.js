import React, { useMemo } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Screen from '../src/components/Screen';
import Button from '../src/components/Button';
import StatCard from '../src/components/StatCard';
import { useStore } from '../src/context/StoreContext';
import { useToast } from '../src/context/ToastContext';
import { resumoVendas } from '../src/utils/calculos';
import { formatarMoeda } from '../src/utils/format';
import { confirmar } from '../src/utils/interacao';
import { colors, fonts, radius, sombra, spacing } from '../src/theme';

const MODULOS = [
  { rota: '/produtos', icone: '📦', titulo: 'Produtos', descricao: 'Cadastro e estoque' },
  { rota: '/usuarios', icone: '👥', titulo: 'Usuários', descricao: 'Equipe de demonstração' },
  { rota: '/vendas', icone: '🧾', titulo: 'Vendas', descricao: 'Histórico de vendas' },
  { rota: '/relatorios', icone: '📊', titulo: 'Relatórios', descricao: 'Indicadores e ranking' },
];

export default function PainelInicial() {
  const router = useRouter();
  const { produtos, vendas, restaurarDados } = useStore();
  const { mostrar } = useToast();

  // Os indicadores são calculados a partir dos dados reais do app.
  const resumo = useMemo(() => resumoVendas(vendas), [vendas]);

  const aoRestaurar = () => {
    confirmar(
      'Restaurar dados',
      'Isso apaga os cadastros e as vendas atuais e volta aos dados de demonstração. Continuar?',
      () => {
        restaurarDados();
        mostrar('Dados de demonstração restaurados.');
      },
      'Restaurar'
    );
  };

  return (
    <Screen>
      <View style={styles.cabecalho}>
        <Text style={styles.nomeApp}>Gestão de Vendas</Text>
        <Text style={styles.subtitulo}>Protótipo acadêmico • todas as vendas são fictícias</Text>
      </View>

      <View style={styles.linhaStats}>
        <StatCard rotulo="Produtos" valor={String(produtos.length)} />
        <StatCard rotulo="Vendas" valor={String(resumo.quantidadeVendas)} />
      </View>
      <StatCard
        rotulo="Valor total vendido"
        valor={formatarMoeda(resumo.valorTotal)}
        style={styles.statLargo}
      />

      <Button
        titulo="＋ Nova venda"
        onPress={() => router.push('/vendas/nova')}
        style={styles.botaoVenda}
      />

      <Text style={styles.secao}>Módulos</Text>
      <View style={styles.grade}>
        {MODULOS.map((modulo) => (
          <Pressable
            key={modulo.rota}
            onPress={() => router.push(modulo.rota)}
            accessibilityRole="button"
            accessibilityLabel={`${modulo.titulo}. ${modulo.descricao}`}
            style={({ pressed }) => [styles.modulo, pressed && styles.moduloPressionado]}
          >
            <Text style={styles.moduloIcone}>{modulo.icone}</Text>
            <Text style={styles.moduloTitulo}>{modulo.titulo}</Text>
            <Text style={styles.moduloDescricao}>{modulo.descricao}</Text>
          </Pressable>
        ))}
      </View>

      <Text style={styles.nota}>
        Os dados ficam salvos neste aparelho. Não há login real, pagamentos nem emissão fiscal.
      </Text>
      <Button titulo="Restaurar dados de demonstração" variante="secundario" onPress={aoRestaurar} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  cabecalho: { marginBottom: spacing.md },
  nomeApp: { fontSize: fonts.grande, fontWeight: '800', color: colors.texto },
  subtitulo: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2 },
  linhaStats: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  statLargo: { flex: 0, marginBottom: spacing.md },
  botaoVenda: { marginBottom: spacing.lg },
  secao: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto, marginBottom: 10 },
  grade: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: spacing.lg },
  modulo: {
    flexGrow: 1,
    flexBasis: '45%',
    minHeight: 110,
    backgroundColor: colors.superficie,
    borderRadius: radius.lg,
    padding: spacing.md,
    ...sombra,
  },
  moduloPressionado: { opacity: 0.8 },
  moduloIcone: { fontSize: 28, marginBottom: 6 },
  moduloTitulo: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  moduloDescricao: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2 },
  nota: { fontSize: fonts.pequena, color: colors.textoSuave, marginBottom: 12 },
});
