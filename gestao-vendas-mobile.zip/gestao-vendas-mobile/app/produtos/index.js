import React, { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import Field from '../../src/components/Field';
import RodapeFixo from '../../src/components/RodapeFixo';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { formatarMoeda } from '../../src/utils/format';
import { confirmar } from '../../src/utils/interacao';
import { colors, fonts, spacing } from '../../src/theme';

export default function ListaProdutos() {
  const router = useRouter();
  const { produtos, excluirProduto } = useStore();
  const { mostrar } = useToast();
  const [busca, setBusca] = useState('');

  const filtrados = useMemo(() => {
    const termo = busca.trim().toLowerCase();
    if (!termo) return produtos;
    return produtos.filter(
      (p) =>
        p.nome.toLowerCase().includes(termo) ||
        p.codigo.toLowerCase().includes(termo) ||
        p.categoria.toLowerCase().includes(termo)
    );
  }, [produtos, busca]);

  const aoExcluir = (produto) => {
    confirmar(
      'Excluir produto',
      `Deseja excluir "${produto.nome}"? Esta ação não pode ser desfeita.`,
      () => {
        excluirProduto(produto.id);
        mostrar(`Produto "${produto.nome}" excluído.`);
      }
    );
  };

  const vazio =
    produtos.length === 0 ? (
      <EmptyState
        titulo="Nenhum produto cadastrado"
        mensagem="Cadastre o primeiro produto para poder registrar vendas."
        acaoTitulo="Cadastrar produto"
        onAcao={() => router.push('/produtos/form')}
      />
    ) : (
      <EmptyState
        icone="🔎"
        titulo="Nada encontrado"
        mensagem={`Nenhum produto corresponde a "${busca}".`}
      />
    );

  return (
    <View style={styles.tela}>
      <View style={styles.busca}>
        <Field
          rotulo="Buscar produto"
          placeholder="Nome, código ou categoria"
          value={busca}
          onChangeText={setBusca}
          autoCorrect={false}
        />
      </View>

      <FlatList
        data={filtrados}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.lista}
        keyboardShouldPersistTaps="handled"
        ListEmptyComponent={vazio}
        renderItem={({ item }) => {
          const semEstoque = item.estoque === 0;
          const estoqueBaixo = item.estoque > 0 && item.estoque <= 5;
          return (
            <Card>
              <Pressable
                onPress={() => router.push(`/produtos/${item.id}`)}
                accessibilityRole="button"
                accessibilityLabel={`Ver detalhes de ${item.nome}`}
              >
                <View style={styles.linhaTopo}>
                  <Text style={styles.nome}>{item.nome}</Text>
                  <Text style={styles.preco}>{formatarMoeda(item.preco)}</Text>
                </View>
                <Text style={styles.meta}>
                  Cód. {item.codigo} • {item.categoria}
                </Text>
                <Text style={[styles.estoque, (semEstoque || estoqueBaixo) && styles.estoqueAlerta]}>
                  Estoque: {item.estoque} un.
                  {semEstoque ? ' — sem estoque' : estoqueBaixo ? ' — estoque baixo' : ''}
                </Text>
              </Pressable>
              <View style={styles.acoes}>
                <Button
                  titulo="Editar"
                  variante="secundario"
                  style={styles.botaoAcao}
                  acessibilidadeLabel={`Editar ${item.nome}`}
                  onPress={() => router.push({ pathname: '/produtos/form', params: { id: item.id } })}
                />
                <Button
                  titulo="Excluir"
                  variante="perigoSuave"
                  style={styles.botaoAcao}
                  acessibilidadeLabel={`Excluir ${item.nome}`}
                  onPress={() => aoExcluir(item)}
                />
              </View>
            </Card>
          );
        }}
      />

      <RodapeFixo>
        <Button titulo="＋ Novo produto" onPress={() => router.push('/produtos/form')} />
      </RodapeFixo>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: colors.fundo },
  busca: { paddingHorizontal: spacing.md, paddingTop: spacing.md },
  lista: { paddingHorizontal: spacing.md, paddingBottom: spacing.md },
  linhaTopo: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 8 },
  nome: { flex: 1, fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  preco: { fontSize: fonts.subtitulo, fontWeight: '800', color: colors.primaria },
  meta: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 4 },
  estoque: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 4, fontWeight: '600' },
  estoqueAlerta: { color: colors.perigo },
  acoes: { flexDirection: 'row', gap: 10, marginTop: 12 },
  botaoAcao: { flex: 1 },
});
