import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Chips from '../../src/components/Chips';
import EmptyState from '../../src/components/EmptyState';
import Field from '../../src/components/Field';
import Screen from '../../src/components/Screen';
import useParamId from '../../src/hooks/useParamId';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { precoParaTexto } from '../../src/utils/format';
import { voltar } from '../../src/utils/interacao';
import { validarProduto } from '../../src/utils/validacao';
import { colors, fonts } from '../../src/theme';

function FormularioProduto({ id }) {
  const router = useRouter();
  const { produtos, salvarProduto } = useStore();
  const { mostrar } = useToast();

  const existente = id ? produtos.find((p) => p.id === id) : undefined;

  const [campos, setCampos] = useState({
    nome: existente ? existente.nome : '',
    codigo: existente ? existente.codigo : '',
    categoria: existente ? existente.categoria : '',
    preco: existente ? precoParaTexto(existente.preco) : '',
    estoque: existente ? String(existente.estoque) : '',
  });
  const [erros, setErros] = useState({});

  // Categorias já usadas, para o usuário tocar em vez de digitar de novo.
  const categorias = useMemo(() => Array.from(new Set(produtos.map((p) => p.categoria))), [produtos]);

  if (id && !existente) {
    return (
      <Screen>
        <EmptyState
          titulo="Produto não encontrado"
          mensagem="Ele pode ter sido excluído."
          acaoTitulo="Voltar para produtos"
          onAcao={() => router.replace('/produtos')}
        />
      </Screen>
    );
  }

  // Devolve uma função que atualiza um campo e limpa o erro dele.
  const alterar = (campo) => (texto) => {
    setCampos((atual) => ({ ...atual, [campo]: texto }));
    if (erros[campo]) setErros((atual) => ({ ...atual, [campo]: undefined }));
  };

  const salvar = () => {
    const resultado = validarProduto(campos, produtos, id);
    if (!resultado.valido) {
      setErros(resultado.erros);
      mostrar('Corrija os campos destacados.', 'erro');
      return;
    }
    salvarProduto(resultado.valores, id);
    mostrar(id ? 'Produto atualizado com sucesso.' : 'Produto cadastrado com sucesso.');
    voltar(router, '/produtos');
  };

  return (
    <Screen>
      <Stack.Screen options={{ title: id ? 'Editar produto' : 'Novo produto' }} />

      <Field
        rotulo="Nome do produto"
        placeholder="Ex.: Caderno universitário"
        value={campos.nome}
        onChangeText={alterar('nome')}
        erro={erros.nome}
      />
      <Field
        rotulo="Código / identificador"
        placeholder="Ex.: CAD-001"
        value={campos.codigo}
        onChangeText={alterar('codigo')}
        autoCapitalize="characters"
        autoCorrect={false}
        erro={erros.codigo}
      />
      <Field
        rotulo="Categoria"
        placeholder="Ex.: Papelaria"
        value={campos.categoria}
        onChangeText={alterar('categoria')}
        erro={erros.categoria}
      />
      {categorias.length > 0 ? (
        <View style={styles.sugestoes}>
          <Chips
            rotulo="Categorias já cadastradas (toque para usar)"
            opcoes={categorias}
            valor={campos.categoria.trim()}
            onChange={alterar('categoria')}
          />
        </View>
      ) : null}
      <Field
        rotulo="Preço de venda (R$)"
        placeholder="Ex.: 18,90"
        value={campos.preco}
        onChangeText={alterar('preco')}
        keyboardType="decimal-pad"
        erro={erros.preco}
      />
      <Field
        rotulo="Quantidade em estoque"
        placeholder="Ex.: 20"
        value={campos.estoque}
        onChangeText={alterar('estoque')}
        keyboardType="number-pad"
        erro={erros.estoque}
      />

      <Text style={styles.nota}>Todos os campos são obrigatórios.</Text>

      <View style={styles.acoes}>
        <Button titulo="Cancelar" variante="secundario" style={styles.botao} onPress={() => voltar(router, '/produtos')} />
        <Button titulo="Salvar" style={styles.botao} onPress={salvar} />
      </View>
    </Screen>
  );
}

export default function ProdutoForm() {
  const id = useParamId();
  // "key" faz o formulário recomeçar do zero quando muda de produto.
  return <FormularioProduto id={id} key={id || 'novo'} />;
}

const styles = StyleSheet.create({
  sugestoes: { marginTop: -4 },
  nota: { fontSize: fonts.pequena, color: colors.textoSuave, marginBottom: 12 },
  acoes: { flexDirection: 'row', gap: 12 },
  botao: { flex: 1 },
});
