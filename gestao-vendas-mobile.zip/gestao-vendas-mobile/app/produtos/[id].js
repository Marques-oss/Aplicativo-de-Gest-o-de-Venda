import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import Info from '../../src/components/Info';
import Screen from '../../src/components/Screen';
import useParamId from '../../src/hooks/useParamId';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { formatarMoeda } from '../../src/utils/format';
import { confirmar, voltar } from '../../src/utils/interacao';

export default function DetalheProduto() {
  const id = useParamId();
  const router = useRouter();
  const { produtos, excluirProduto } = useStore();
  const { mostrar } = useToast();

  const produto = produtos.find((p) => p.id === id);

  if (!produto) {
    return (
      <Screen>
        <EmptyState
          titulo="Produto não encontrado"
          mensagem="Ele pode ter sido excluído."
          acaoTitulo="Voltar para produtos"
          onAcao={() => router.replace('/produtos')}
        />
      </Screen>
    );
  }

  const aoExcluir = () => {
    confirmar(
      'Excluir produto',
      `Deseja excluir "${produto.nome}"? Esta ação não pode ser desfeita.`,
      () => {
        voltar(router, '/produtos');
        excluirProduto(produto.id);
        mostrar(`Produto "${produto.nome}" excluído.`);
      }
    );
  };

  return (
    <Screen>
      <Card>
        <Info rotulo="Nome" valor={produto.nome} />
        <Info rotulo="Código / identificador" valor={produto.codigo} />
        <Info rotulo="Categoria" valor={produto.categoria} />
        <Info rotulo="Preço de venda" valor={formatarMoeda(produto.preco)} destaque />
        <Info rotulo="Estoque" valor={`${produto.estoque} unidade(s)`} />
      </Card>

      <View style={styles.acoes}>
        <Button
          titulo="Editar"
          variante="secundario"
          style={styles.botao}
          onPress={() => router.push({ pathname: '/produtos/form', params: { id: produto.id } })}
        />
        <Button titulo="Excluir" variante="perigoSuave" style={styles.botao} onPress={aoExcluir} />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  acoes: { flexDirection: 'row', gap: 12 },
  botao: { flex: 1 },
});
