import React from 'react';
import { ActivityIndicator, Text, View } from 'react-native';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StoreProvider, useStore } from '../src/context/StoreContext';
import { ToastProvider } from '../src/context/ToastContext';
import { colors } from '../src/theme';

// Define as telas do app e o visual do cabeçalho.
function Navegacao() {
  const { carregado } = useStore();

  if (!carregado) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          backgroundColor: colors.fundo,
        }}
      >
        <ActivityIndicator size="large" color={colors.primaria} />
        <Text style={{ marginTop: 12, color: colors.textoSuave }}>Carregando dados...</Text>
      </View>
    );
  }

  return (
    <Stack
      screenOptions={{
        headerStyle: { backgroundColor: colors.primaria },
        headerTintColor: '#FFFFFF',
        headerTitleStyle: { fontWeight: '700' },
        contentStyle: { backgroundColor: colors.fundo },
      }}
    >
      <Stack.Screen name="index" options={{ title: 'Gestão de Vendas' }} />
      <Stack.Screen name="produtos/index" options={{ title: 'Produtos' }} />
      <Stack.Screen name="produtos/form" options={{ title: 'Produto' }} />
      <Stack.Screen name="produtos/[id]" options={{ title: 'Detalhes do produto' }} />
      <Stack.Screen name="usuarios/index" options={{ title: 'Usuários' }} />
      <Stack.Screen name="usuarios/form" options={{ title: 'Usuário' }} />
      <Stack.Screen name="usuarios/[id]" options={{ title: 'Detalhes do usuário' }} />
      <Stack.Screen name="vendas/index" options={{ title: 'Histórico de vendas' }} />
      <Stack.Screen name="vendas/nova" options={{ title: 'Nova venda' }} />
      <Stack.Screen name="vendas/[id]" options={{ title: 'Detalhes da venda' }} />
      <Stack.Screen name="relatorios" options={{ title: 'Relatórios' }} />
    </Stack>
  );
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <StoreProvider>
        <ToastProvider>
          <StatusBar style="light" />
          <Navegacao />
        </ToastProvider>
      </StoreProvider>
    </SafeAreaProvider>
  );
}
