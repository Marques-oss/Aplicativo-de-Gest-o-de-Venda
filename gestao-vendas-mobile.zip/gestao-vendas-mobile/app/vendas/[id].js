import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import Info from '../../src/components/Info';
import Screen from '../../src/components/Screen';
import useParamId from '../../src/hooks/useParamId';
import { useStore } from '../../src/context/StoreContext';
import { formatarDataHora, formatarMoeda } from '../../src/utils/format';
import { colors, fonts } from '../../src/theme';

export default function DetalheVenda() {
  const id = useParamId();
  const router = useRouter();
  const { vendas } = useStore();

  const venda = vendas.find((v) => v.id === id);

  if (!venda) {
    return (
      <Screen>
        <EmptyState
          titulo="Venda não encontrada"
          acaoTitulo="Ver histórico"
          onAcao={() => router.replace('/vendas')}
        />
      </Screen>
    );
  }

  return (
    <Screen>
      <Card>
        <Info rotulo="Identificador" valor={venda.id} />
        <Info rotulo="Data e hora" valor={formatarDataHora(venda.dataHora)} />
        <Info rotulo="Total" valor={formatarMoeda(venda.total)} destaque />
      </Card>

      <Text style={styles.titulo}>Itens da venda</Text>
      {venda.itens.map((item) => (
        <Card key={item.produtoId}>
          <Text style={styles.nome}>{item.nome}</Text>
          <View style={styles.linha}>
            <Text style={styles.detalhe}>
              {item.quantidade} × {formatarMoeda(item.precoUnitario)}
            </Text>
            <Text style={styles.subtotal}>{formatarMoeda(item.subtotal)}</Text>
          </View>
        </Card>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  titulo: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto, marginVertical: 8 },
  nome: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  linha: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
  detalhe: { fontSize: fonts.normal, color: colors.textoSuave },
  subtotal: { fontSize: fonts.normal, fontWeight: '800', color: colors.primaria },
});
