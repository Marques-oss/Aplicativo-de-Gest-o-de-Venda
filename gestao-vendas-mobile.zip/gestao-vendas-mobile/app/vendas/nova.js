import React, { useMemo, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import Field from '../../src/components/Field';
import Screen from '../../src/components/Screen';
import { useStore } from '../../src/context/StoreContext';
import { useToast } from '../../src/context/ToastContext';
import { calcularSubtotal, calcularTotal } from '../../src/utils/calculos';
import { formatarDataHora, formatarMoeda } from '../../src/utils/format';
import { converterInteiro, validarQuantidadeVenda } from '../../src/utils/validacao';
import { colors, fonts, radius, spacing } from '../../src/theme';

// A venda acontece em 3 etapas: "montar" -> "revisar" -> "concluida".
export default function NovaVenda() {
  const router = useRouter();
  const { produtos, registrarVenda } = useStore();
  const { mostrar } = useToast();

  const [carrinho, setCarrinho] = useState([]); // [{ produtoId, quantidadeTexto }]
  const [erros, setErros] = useState({}); // { produtoId: 'mensagem' }
  const [etapa, setEtapa] = useState('montar');
  const [vendaConcluida, setVendaConcluida] = useState(null);

  // Junta cada item do carrinho com os dados atuais do produto.
  const linhas = useMemo(() => {
    return carrinho
      .map((item) => {
        const produto = produtos.find((p) => p.id === item.produtoId);
        if (!produto) return null;
        const quantidade = converterInteiro(item.quantidadeTexto);
        const valida = Number.isInteger(quantidade) && quantidade > 0;
        return {
          produto,
          quantidadeTexto: item.quantidadeTexto,
          quantidade,
          valida,
          subtotal: valida ? calcularSubtotal(produto.preco, quantidade) : null,
        };
      })
      .filter(Boolean);
  }, [carrinho, produtos]);

  // Total em tempo real (considera só as quantidades válidas).
  const totalParcial = useMemo(
    () =>
      calcularTotal(
        linhas
          .filter((l) => l.valida)
          .map((l) => ({ precoUnitario: l.produto.preco, quantidade: l.quantidade }))
      ),
    [linhas]
  );

  const adicionar = (produto) => {
    setCarrinho((atual) => [...atual, { produtoId: produto.id, quantidadeTexto: '1' }]);
  };

  const remover = (produtoId) => {
    setCarrinho((atual) => atual.filter((i) => i.produtoId !== produtoId));
    setErros((atual) => ({ ...atual, [produtoId]: undefined }));
  };

  const alterarQuantidade = (produtoId, texto) => {
    setCarrinho((atual) =>
      atual.map((i) => (i.produtoId === produtoId ? { ...i, quantidadeTexto: texto } : i))
    );
    if (erros[produtoId]) setErros((atual) => ({ ...atual, [produtoId]: undefined }));
  };

  const revisar = () => {
    if (linhas.length === 0) {
      mostrar('Adicione pelo menos um produto à venda.', 'erro');
      return;
    }

    const novosErros = {};
    for (const linha of linhas) {
      const resultado = validarQuantidadeVenda(linha.quantidadeTexto, linha.produto.estoque);
      if (!resultado.ok) novosErros[linha.produto.id] = resultado.erro;
    }

    if (Object.keys(novosErros).length > 0) {
      setErros(novosErros);
      mostrar('Corrija as quantidades destacadas.', 'erro');
      return;
    }

    setErros({});
    setEtapa('revisar');
  };

  const confirmarVenda = () => {
    const resultado = registrarVenda(
      linhas.map((l) => ({ produtoId: l.produto.id, quantidade: l.quantidade }))
    );

    if (!resultado.ok) {
      mostrar(resultado.erro, 'erro');
      setEtapa('montar');
      return;
    }

    setVendaConcluida(resultado.venda);
    setEtapa('concluida');
    mostrar(`Venda ${resultado.venda.id} registrada com sucesso!`);
  };

  const novaVenda = () => {
    setCarrinho([]);
    setErros({});
    setVendaConcluida(null);
    setEtapa('montar');
  };

  // ---------- Etapa 3: confirmação visual ----------
  if (etapa === 'concluida' && vendaConcluida) {
    return (
      <Screen>
        <View style={styles.sucesso} accessibilityLiveRegion="polite">
          <Text style={styles.sucessoIcone}>✅</Text>
          <Text style={styles.sucessoTitulo}>Venda registrada!</Text>
          <Text style={styles.sucessoTexto}>
            {vendaConcluida.id} • {formatarDataHora(vendaConcluida.dataHora)}
          </Text>
          <Text style={styles.sucessoTotal}>{formatarMoeda(vendaConcluida.total)}</Text>
          <Text style={styles.sucessoTexto}>Venda fictícia — nenhum pagamento real foi feito.</Text>
        </View>

        <Button titulo="＋ Registrar outra venda" onPress={novaVenda} style={styles.espaco} />
        <Button
          titulo="Ver detalhes desta venda"
          variante="secundario"
          style={styles.espaco}
          onPress={() => router.replace(`/vendas/${vendaConcluida.id}`)}
        />
        <Button
          titulo="Ver histórico de vendas"
          variante="secundario"
          onPress={() => router.replace('/vendas')}
        />
      </Screen>
    );
  }

  // ---------- Etapa 2: revisar antes de confirmar ----------
  if (etapa === 'revisar') {
    return (
      <Screen>
        <Text style={styles.titulo}>Revise a venda</Text>
        <Text style={styles.ajuda}>Confira os itens e o total antes de confirmar.</Text>

        {linhas.map((linha) => (
          <Card key={linha.produto.id}>
            <Text style={styles.nomeItem}>{linha.produto.nome}</Text>
            <Text style={styles.detalheItem}>
              {linha.quantidade} × {formatarMoeda(linha.produto.preco)}
            </Text>
            <Text style={styles.subtotal}>Subtotal: {formatarMoeda(linha.subtotal)}</Text>
          </Card>
        ))}

        <View style={styles.caixaTotal}>
          <Text style={styles.totalRotulo}>Total da venda</Text>
          <Text style={styles.totalValor}>{formatarMoeda(totalParcial)}</Text>
        </View>

        <View style={styles.acoes}>
          <Button
            titulo="Voltar e editar"
            variante="secundario"
            style={styles.botao}
            onPress={() => setEtapa('montar')}
          />
          <Button titulo="Confirmar venda" style={styles.botao} onPress={confirmarVenda} />
        </View>
      </Screen>
    );
  }

  // ---------- Etapa 1: montar a venda ----------
  if (produtos.length === 0) {
    return (
      <Screen>
        <EmptyState
          titulo="Nenhum produto cadastrado"
          mensagem="Cadastre produtos antes de registrar uma venda."
          acaoTitulo="Cadastrar produto"
          onAcao={() => router.replace('/produtos/form')}
        />
      </Screen>
    );
  }

  return (
    <Screen>
      <Text style={styles.titulo}>1. Escolha os produtos</Text>
      {produtos.map((produto) => {
        const noCarrinho = carrinho.some((i) => i.produtoId === produto.id);
        const semEstoque = produto.estoque === 0;
        return (
          <Card key={produto.id}>
            <View style={styles.linhaProduto}>
              <View style={styles.dadosProduto}>
                <Text style={styles.nomeItem}>{produto.nome}</Text>
                <Text style={styles.detalheItem}>
                  {formatarMoeda(produto.preco)} • Estoque: {produto.estoque}
                </Text>
              </View>
              <Button
                titulo={semEstoque ? 'Sem estoque' : noCarrinho ? 'Adicionado ✓' : 'Adicionar'}
                variante="secundario"
                desabilitado={semEstoque || noCarrinho}
                onPress={() => adicionar(produto)}
                acessibilidadeLabel={`Adicionar ${produto.nome} à venda`}
              />
            </View>
          </Card>
        );
      })}

      <Text style={[styles.titulo, styles.tituloSecao]}>2. Informe as quantidades</Text>
      {linhas.length === 0 ? (
        <Text style={styles.ajuda}>Nenhum item adicionado ainda.</Text>
      ) : (
        linhas.map((linha) => (
          <Card key={linha.produto.id}>
            <Text style={styles.nomeItem}>{linha.produto.nome}</Text>
            <Text style={styles.detalheItem}>
              {formatarMoeda(linha.produto.preco)} • Disponível: {linha.produto.estoque}
            </Text>
            <Field
              rotulo="Quantidade"
              value={linha.quantidadeTexto}
              onChangeText={(texto) => alterarQuantidade(linha.produto.id, texto)}
              keyboardType="number-pad"
              erro={erros[linha.produto.id]}
              style={styles.campoQuantidade}
            />
            <View style={styles.linhaSubtotal}>
              <Text style={styles.subtotal}>
                Subtotal: {linha.valida ? formatarMoeda(linha.subtotal) : '—'}
              </Text>
              <Button
                titulo="Remover"
                variante="perigoSuave"
                onPress={() => remover(linha.produto.id)}
                acessibilidadeLabel={`Remover ${linha.produto.nome} da venda`}
              />
            </View>
          </Card>
        ))
      )}

      <View style={styles.caixaTotal}>
        <Text style={styles.totalRotulo}>Total da venda</Text>
        <Text style={styles.totalValor}>{formatarMoeda(totalParcial)}</Text>
      </View>

      <Button titulo="Revisar venda" onPress={revisar} />
    </Screen>
  );
}

const styles = StyleSheet.create({
  titulo: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto, marginBottom: 10 },
  tituloSecao: { marginTop: spacing.md },
  ajuda: { fontSize: fonts.normal, color: colors.textoSuave, marginBottom: 12 },
  linhaProduto: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  dadosProduto: { flex: 1 },
  nomeItem: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  detalheItem: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2, marginBottom: 8 },
  campoQuantidade: { fontSize: fonts.subtitulo, fontWeight: '700' },
  linhaSubtotal: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', gap: 12 },
  subtotal: { fontSize: fonts.normal, fontWeight: '700', color: colors.primaria },
  caixaTotal: {
    backgroundColor: colors.primariaClara,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginVertical: spacing.md,
  },
  totalRotulo: { fontSize: fonts.pequena, color: colors.textoSuave, fontWeight: '700' },
  totalValor: { fontSize: fonts.grande, fontWeight: '800', color: colors.primaria },
  acoes: { flexDirection: 'row', gap: 12 },
  botao: { flex: 1 },
  espaco: { marginBottom: 12 },
  sucesso: {
    alignItems: 'center',
    backgroundColor: colors.sucessoClaro,
    borderRadius: radius.lg,
    padding: spacing.lg,
    marginBottom: spacing.lg,
  },
  sucessoIcone: { fontSize: 56 },
  sucessoTitulo: { fontSize: fonts.titulo, fontWeight: '800', color: colors.sucesso, marginTop: 8 },
  sucessoTexto: { fontSize: fonts.pequena, color: colors.sucesso, marginTop: 4, textAlign: 'center' },
  sucessoTotal: { fontSize: fonts.grande, fontWeight: '800', color: colors.sucesso, marginVertical: 8 },
});
