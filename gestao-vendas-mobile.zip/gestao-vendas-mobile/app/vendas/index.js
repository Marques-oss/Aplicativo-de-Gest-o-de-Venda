import React from 'react';
import { FlatList, Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import Button from '../../src/components/Button';
import Card from '../../src/components/Card';
import EmptyState from '../../src/components/EmptyState';
import RodapeFixo from '../../src/components/RodapeFixo';
import { useStore } from '../../src/context/StoreContext';
import { formatarDataHora, formatarMoeda } from '../../src/utils/format';
import { colors, fonts, spacing } from '../../src/theme';

export default function HistoricoVendas() {
  const router = useRouter();
  const { vendas } = useStore();

  return (
    <View style={styles.tela}>
      <FlatList
        data={vendas}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.lista}
        ListEmptyComponent={
          <EmptyState
            icone="🧾"
            titulo="Nenhuma venda registrada"
            mensagem="As vendas fictícias que você registrar vão aparecer aqui."
            acaoTitulo="Registrar primeira venda"
            onAcao={() => router.push('/vendas/nova')}
          />
        }
        renderItem={({ item }) => {
          const totalItens = item.itens.reduce((soma, i) => soma + i.quantidade, 0);
          return (
            <Card>
              <Pressable
                onPress={() => router.push(`/vendas/${item.id}`)}
                accessibilityRole="button"
                accessibilityLabel={`Ver detalhes da venda ${item.id}`}
              >
                <View style={styles.linha}>
                  <Text style={styles.id}>{item.id}</Text>
                  <Text style={styles.total}>{formatarMoeda(item.total)}</Text>
                </View>
                <Text style={styles.meta}>{formatarDataHora(item.dataHora)}</Text>
                <Text style={styles.meta}>
                  {totalItens} {totalItens === 1 ? 'item' : 'itens'} • toque para ver detalhes
                </Text>
              </Pressable>
            </Card>
          );
        }}
      />

      <RodapeFixo>
        <Button titulo="＋ Nova venda" onPress={() => router.push('/vendas/nova')} />
      </RodapeFixo>
    </View>
  );
}

const styles = StyleSheet.create({
  tela: { flex: 1, backgroundColor: colors.fundo },
  lista: { padding: spacing.md },
  linha: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  id: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto },
  total: { fontSize: fonts.subtitulo, fontWeight: '800', color: colors.primaria },
  meta: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 4 },
});
