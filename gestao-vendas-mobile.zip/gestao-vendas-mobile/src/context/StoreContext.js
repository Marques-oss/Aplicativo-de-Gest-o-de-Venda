import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { produtosIniciais, usuariosIniciais } from '../data/seed';
import { calcularSubtotal, calcularTotal } from '../utils/calculos';

// Todos os dados do app (produtos, usuários e vendas) ficam aqui.
// Eles são salvos no armazenamento local do aparelho (AsyncStorage), então
// continuam existindo quando o app é fechado e aberto de novo.

const CHAVE_ARMAZENAMENTO = '@gestao-vendas/dados-v1';

function dadosDeDemonstracao() {
  return {
    produtos: produtosIniciais.map((p) => ({ ...p })),
    usuarios: usuariosIniciais.map((u) => ({ ...u })),
    vendas: [],
  };
}

function dadosValidos(d) {
  return (
    d && Array.isArray(d.produtos) && Array.isArray(d.usuarios) && Array.isArray(d.vendas)
  );
}

function gerarId(prefixo) {
  return `${prefixo}${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

const StoreContext = createContext(null);

export function StoreProvider({ children }) {
  const [dados, setDados] = useState({ produtos: [], usuarios: [], vendas: [] });
  const [carregado, setCarregado] = useState(false);

  // 1) Ao abrir o app: lê os dados salvos (ou usa os de demonstração).
  useEffect(() => {
    let ativo = true;

    async function carregar() {
      let inicial = dadosDeDemonstracao();
      try {
        const texto = await AsyncStorage.getItem(CHAVE_ARMAZENAMENTO);
        if (texto) {
          const salvo = JSON.parse(texto);
          if (dadosValidos(salvo)) inicial = salvo;
        }
      } catch (erro) {
        // Se não conseguir ler, começa com os dados de demonstração.
      }
      if (ativo) {
        setDados(inicial);
        setCarregado(true);
      }
    }

    carregar();
    return () => {
      ativo = false;
    };
  }, []);

  // 2) Sempre que os dados mudam: salva no aparelho.
  useEffect(() => {
    if (!carregado) return;
    AsyncStorage.setItem(CHAVE_ARMAZENAMENTO, JSON.stringify(dados)).catch(() => {});
  }, [dados, carregado]);

  // ---------- Produtos ----------
  const salvarProduto = useCallback((valores, id) => {
    setDados((anterior) => {
      if (id) {
        return {
          ...anterior,
          produtos: anterior.produtos.map((p) => (p.id === id ? { ...p, ...valores } : p)),
        };
      }
      return {
        ...anterior,
        produtos: [...anterior.produtos, { id: gerarId('p'), ...valores }],
      };
    });
  }, []);

  const excluirProduto = useCallback((id) => {
    setDados((anterior) => ({
      ...anterior,
      produtos: anterior.produtos.filter((p) => p.id !== id),
    }));
  }, []);

  // ---------- Usuários ----------
  const salvarUsuario = useCallback((valores, id) => {
    setDados((anterior) => {
      if (id) {
        return {
          ...anterior,
          usuarios: anterior.usuarios.map((u) => (u.id === id ? { ...u, ...valores } : u)),
        };
      }
      return {
        ...anterior,
        usuarios: [...anterior.usuarios, { id: gerarId('u'), ...valores }],
      };
    });
  }, []);

  const excluirUsuario = useCallback((id) => {
    setDados((anterior) => ({
      ...anterior,
      usuarios: anterior.usuarios.filter((u) => u.id !== id),
    }));
  }, []);

  // ---------- Vendas ----------
  // itens: [{ produtoId, quantidade }]
  // Retorna { ok: true, venda } ou { ok: false, erro }
  const registrarVenda = useCallback(
    (itens) => {
      if (!itens || itens.length === 0) {
        return { ok: false, erro: 'Adicione ao menos um item à venda.' };
      }

      const itensVenda = [];
      for (const item of itens) {
        const produto = dados.produtos.find((p) => p.id === item.produtoId);
        if (!produto) {
          return { ok: false, erro: 'Um dos produtos da venda não existe mais.' };
        }
        if (!Number.isInteger(item.quantidade) || item.quantidade <= 0) {
          return { ok: false, erro: `Quantidade inválida para "${produto.nome}".` };
        }
        if (item.quantidade > produto.estoque) {
          return {
            ok: false,
            erro: `Estoque insuficiente para "${produto.nome}" (disponível: ${produto.estoque}).`,
          };
        }
        itensVenda.push({
          produtoId: produto.id,
          nome: produto.nome,
          precoUnitario: produto.preco,
          quantidade: item.quantidade,
          subtotal: calcularSubtotal(produto.preco, item.quantidade),
        });
      }

      const numero = dados.vendas.reduce((maior, v) => Math.max(maior, v.numero || 0), 0) + 1;
      const venda = {
        id: `V-${String(numero).padStart(4, '0')}`,
        numero,
        dataHora: new Date().toISOString(),
        itens: itensVenda,
        total: calcularTotal(itensVenda),
      };

      setDados((anterior) => ({
        ...anterior,
        // baixa o estoque (nunca fica negativo, pois validamos acima)
        produtos: anterior.produtos.map((p) => {
          const vendido = itensVenda.find((i) => i.produtoId === p.id);
          return vendido ? { ...p, estoque: p.estoque - vendido.quantidade } : p;
        }),
        vendas: [venda, ...anterior.vendas],
      }));

      return { ok: true, venda };
    },
    [dados]
  );

  const restaurarDados = useCallback(() => {
    setDados(dadosDeDemonstracao());
  }, []);

  const valor = useMemo(
    () => ({
      carregado,
      produtos: dados.produtos,
      usuarios: dados.usuarios,
      vendas: dados.vendas,
      salvarProduto,
      excluirProduto,
      salvarUsuario,
      excluirUsuario,
      registrarVenda,
      restaurarDados,
    }),
    [
      carregado,
      dados,
      salvarProduto,
      excluirProduto,
      salvarUsuario,
      excluirUsuario,
      registrarVenda,
      restaurarDados,
    ]
  );

  return <StoreContext.Provider value={valor}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const contexto = useContext(StoreContext);
  if (!contexto) {
    throw new Error('useStore deve ser usado dentro de <StoreProvider>.');
  }
  return contexto;
}
