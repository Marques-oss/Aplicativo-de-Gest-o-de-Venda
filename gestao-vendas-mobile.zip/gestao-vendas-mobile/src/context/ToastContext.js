import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius, spacing } from '../theme';

// Mensagem rápida que aparece na parte de baixo da tela
// ("Produto salvo com sucesso", "Corrija os campos", etc.).

const ToastContext = createContext(null);

export function ToastProvider({ children }) {
  const [toast, setToast] = useState(null);
  const temporizador = useRef(null);

  const mostrar = useCallback((mensagem, tipo = 'sucesso') => {
    if (temporizador.current) clearTimeout(temporizador.current);
    setToast({ mensagem, tipo });
    temporizador.current = setTimeout(() => setToast(null), 3000);
  }, []);

  useEffect(() => {
    return () => {
      if (temporizador.current) clearTimeout(temporizador.current);
    };
  }, []);

  const valor = useMemo(() => ({ mostrar }), [mostrar]);
  const erro = toast && toast.tipo === 'erro';

  return (
    <ToastContext.Provider value={valor}>
      <View style={styles.raiz}>
        {children}
        {toast ? (
          <View
            pointerEvents="none"
            accessibilityLiveRegion="polite"
            style={[styles.toast, erro ? styles.toastErro : styles.toastSucesso]}
          >
            <Text style={styles.texto}>
              {erro ? '⚠️  ' : '✅  '}
              {toast.mensagem}
            </Text>
          </View>
        ) : null}
      </View>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const contexto = useContext(ToastContext);
  if (!contexto) {
    throw new Error('useToast deve ser usado dentro de <ToastProvider>.');
  }
  return contexto;
}

const styles = StyleSheet.create({
  raiz: { flex: 1 },
  toast: {
    position: 'absolute',
    left: spacing.md,
    right: spacing.md,
    bottom: 96,
    paddingVertical: 14,
    paddingHorizontal: spacing.md,
    borderRadius: radius.md,
    elevation: 8,
    shadowColor: '#000000',
    shadowOpacity: 0.25,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 4 },
  },
  toastSucesso: { backgroundColor: colors.sucesso },
  toastErro: { backgroundColor: colors.perigo },
  texto: { color: '#FFFFFF', fontSize: fonts.normal, fontWeight: '600' },
});
