import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts } from '../theme';

// Linha "Rótulo: valor" usada nas telas de detalhes.
export default function Info({ rotulo, valor, destaque = false }) {
  return (
    <View style={styles.linha}>
      <Text style={styles.rotulo}>{rotulo}</Text>
      <Text style={[styles.valor, destaque && styles.destaque]}>{valor}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  linha: {
    paddingVertical: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.borda,
  },
  rotulo: { fontSize: fonts.pequena, color: colors.textoSuave, marginBottom: 2 },
  valor: { fontSize: fonts.normal, color: colors.texto, fontWeight: '600' },
  destaque: { fontSize: fonts.titulo, color: colors.primaria, fontWeight: '800' },
});
