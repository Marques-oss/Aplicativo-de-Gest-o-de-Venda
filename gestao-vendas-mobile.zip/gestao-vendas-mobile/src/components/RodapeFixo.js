import React from 'react';
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, spacing } from '../theme';

// Barra fixa no rodapé da tela (para o botão principal, ex.: "Novo produto").
export default function RodapeFixo({ children }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.barra, { paddingBottom: insets.bottom + spacing.sm }]}>{children}</View>
  );
}

const styles = StyleSheet.create({
  barra: {
    paddingHorizontal: spacing.md,
    paddingTop: spacing.sm,
    backgroundColor: colors.superficie,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: colors.borda,
  },
});
