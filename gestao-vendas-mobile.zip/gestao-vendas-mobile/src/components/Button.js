import React from 'react';
import { Pressable, StyleSheet, Text } from 'react-native';
import { colors, fonts, radius } from '../theme';

// variante: 'primario' | 'secundario' | 'perigo' | 'perigoSuave'
export default function Button({
  titulo,
  onPress,
  variante = 'primario',
  desabilitado = false,
  style,
  acessibilidadeLabel,
}) {
  const estilo = variantes[variante] || variantes.primario;

  return (
    <Pressable
      onPress={onPress}
      disabled={desabilitado}
      accessibilityRole="button"
      accessibilityLabel={acessibilidadeLabel || titulo}
      accessibilityState={{ disabled: desabilitado }}
      style={({ pressed }) => [
        styles.base,
        estilo.botao,
        pressed && styles.pressionado,
        desabilitado && styles.desabilitado,
        style,
      ]}
    >
      <Text style={[styles.texto, estilo.texto]}>{titulo}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  base: {
    minHeight: 48,
    paddingHorizontal: 16,
    borderRadius: radius.md,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
  },
  texto: { fontSize: fonts.normal, fontWeight: '700', textAlign: 'center' },
  pressionado: { opacity: 0.8 },
  desabilitado: { opacity: 0.5 },
});

const variantes = {
  primario: {
    botao: { backgroundColor: colors.primaria, borderColor: colors.primaria },
    texto: { color: '#FFFFFF' },
  },
  secundario: {
    botao: { backgroundColor: colors.superficie, borderColor: colors.primaria },
    texto: { color: colors.primaria },
  },
  perigo: {
    botao: { backgroundColor: colors.perigo, borderColor: colors.perigo },
    texto: { color: '#FFFFFF' },
  },
  perigoSuave: {
    botao: { backgroundColor: colors.superficie, borderColor: colors.perigo },
    texto: { color: colors.perigo },
  },
};
