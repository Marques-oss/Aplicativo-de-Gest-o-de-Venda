import React from 'react';
import { StyleSheet, View } from 'react-native';
import { colors, radius, sombra, spacing } from '../theme';

export default function Card({ children, style }) {
  return <View style={[styles.card, style]}>{children}</View>;
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: colors.superficie,
    borderRadius: radius.lg,
    padding: spacing.md,
    marginBottom: 12,
    ...sombra,
  },
});
