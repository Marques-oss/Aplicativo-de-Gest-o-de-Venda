import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { colors, fonts } from '../theme';

// Grupo de opções para escolher uma (ex.: perfil do usuário).
export default function Chips({ rotulo, opcoes, valor, onChange, erro }) {
  return (
    <View style={styles.grupo}>
      {rotulo ? <Text style={styles.rotulo}>{rotulo}</Text> : null}
      <View style={styles.linha}>
        {opcoes.map((opcao) => {
          const ativo = opcao === valor;
          return (
            <Pressable
              key={opcao}
              onPress={() => onChange(opcao)}
              accessibilityRole="radio"
              accessibilityLabel={opcao}
              accessibilityState={{ selected: ativo }}
              style={[styles.chip, ativo && styles.chipAtivo]}
            >
              <Text style={[styles.chipTexto, ativo && styles.chipTextoAtivo]}>{opcao}</Text>
            </Pressable>
          );
        })}
      </View>
      {erro ? <Text style={styles.erro}>{erro}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  grupo: { marginBottom: 14 },
  rotulo: { fontSize: fonts.pequena, fontWeight: '700', color: colors.texto, marginBottom: 6 },
  linha: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: {
    minHeight: 44,
    paddingHorizontal: 16,
    borderRadius: 22,
    borderWidth: 1.5,
    borderColor: colors.borda,
    backgroundColor: colors.superficie,
    alignItems: 'center',
    justifyContent: 'center',
  },
  chipAtivo: { backgroundColor: colors.primaria, borderColor: colors.primaria },
  chipTexto: { color: colors.texto, fontSize: fonts.normal, fontWeight: '600' },
  chipTextoAtivo: { color: '#FFFFFF' },
  erro: { color: colors.perigo, fontSize: fonts.pequena, marginTop: 4, fontWeight: '600' },
});
