import React from 'react';
import { StyleSheet, Text, TextInput, View } from 'react-native';
import { colors, fonts, radius } from '../theme';

// Campo de texto com rótulo, mensagem de erro e texto de ajuda.
export default function Field({ rotulo, erro, ajuda, style, ...props }) {
  return (
    <View style={styles.grupo}>
      <Text style={styles.rotulo}>{rotulo}</Text>
      <TextInput
        accessibilityLabel={rotulo}
        placeholderTextColor={colors.placeholder}
        style={[styles.input, erro ? styles.inputErro : null, style]}
        {...props}
      />
      {erro ? (
        <Text style={styles.erro} accessibilityLiveRegion="polite">
          {erro}
        </Text>
      ) : ajuda ? (
        <Text style={styles.ajuda}>{ajuda}</Text>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  grupo: { marginBottom: 14 },
  rotulo: { fontSize: fonts.pequena, fontWeight: '700', color: colors.texto, marginBottom: 6 },
  input: {
    minHeight: 48,
    borderWidth: 1.5,
    borderColor: colors.borda,
    borderRadius: radius.md,
    paddingHorizontal: 12,
    fontSize: fonts.normal,
    color: colors.texto,
    backgroundColor: colors.superficie,
  },
  inputErro: { borderColor: colors.perigo, backgroundColor: '#FFF7F7' },
  erro: { color: colors.perigo, fontSize: fonts.pequena, marginTop: 4, fontWeight: '600' },
  ajuda: { color: colors.textoSuave, fontSize: fonts.pequena, marginTop: 4 },
});
