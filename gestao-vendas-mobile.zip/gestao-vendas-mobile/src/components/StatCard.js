import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors, fonts, radius, sombra, spacing } from '../theme';

// Cartão com um indicador (ex.: "Produtos: 4").
export default function StatCard({ rotulo, valor, style }) {
  return (
    <View
      style={[styles.card, style]}
      accessible
      accessibilityLabel={`${rotulo}: ${valor}`}
    >
      <Text style={styles.valor} numberOfLines={1} adjustsFontSizeToFit>
        {valor}
      </Text>
      <Text style={styles.rotulo}>{rotulo}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    flex: 1,
    minWidth: 100,
    backgroundColor: colors.superficie,
    borderRadius: radius.lg,
    padding: spacing.md,
    ...sombra,
  },
  valor: { fontSize: fonts.titulo, fontWeight: '800', color: colors.primaria },
  rotulo: { fontSize: fonts.pequena, color: colors.textoSuave, marginTop: 2, fontWeight: '600' },
});
