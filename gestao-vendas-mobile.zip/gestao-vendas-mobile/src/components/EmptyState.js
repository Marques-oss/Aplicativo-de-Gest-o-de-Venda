import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import Button from './Button';
import { colors, fonts, spacing } from '../theme';

// Mostrado quando uma lista está vazia ou algo não foi encontrado.
export default function EmptyState({ icone = '📭', titulo, mensagem, acaoTitulo, onAcao }) {
  return (
    <View style={styles.caixa}>
      <Text style={styles.icone} accessibilityElementsHidden importantForAccessibility="no">
        {icone}
      </Text>
      <Text style={styles.titulo}>{titulo}</Text>
      {mensagem ? <Text style={styles.mensagem}>{mensagem}</Text> : null}
      {acaoTitulo && onAcao ? (
        <Button titulo={acaoTitulo} onPress={onAcao} style={styles.botao} />
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  caixa: { alignItems: 'center', paddingVertical: spacing.xl, paddingHorizontal: spacing.md },
  icone: { fontSize: 44, marginBottom: spacing.sm },
  titulo: { fontSize: fonts.subtitulo, fontWeight: '700', color: colors.texto, textAlign: 'center' },
  mensagem: {
    fontSize: fonts.normal,
    color: colors.textoSuave,
    textAlign: 'center',
    marginTop: spacing.xs,
  },
  botao: { marginTop: spacing.md, alignSelf: 'stretch' },
});
