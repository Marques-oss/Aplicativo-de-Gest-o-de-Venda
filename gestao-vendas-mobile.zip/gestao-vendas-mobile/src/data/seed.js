// Dados de demonstração (usados na primeira vez que o app abre
// e quando o usuário toca em "Restaurar dados de demonstração").

export const produtosIniciais = [
  {
    id: 'p1',
    nome: 'Caderno universitário',
    codigo: 'CAD-001',
    categoria: 'Papelaria',
    preco: 18.9,
    estoque: 20,
  },
  {
    id: 'p2',
    nome: 'Caneta azul',
    codigo: 'CAN-001',
    categoria: 'Papelaria',
    preco: 2.5,
    estoque: 100,
  },
  {
    id: 'p3',
    nome: 'Garrafa térmica',
    codigo: 'GAR-001',
    categoria: 'Acessórios',
    preco: 39.9,
    estoque: 12,
  },
  {
    id: 'p4',
    nome: 'Mochila básica',
    codigo: 'MOC-001',
    categoria: 'Acessórios',
    preco: 89.9,
    estoque: 8,
  },
];

export const usuariosIniciais = [
  { id: 'u1', nome: 'Maria Souza', email: 'maria@exemplo.com', perfil: 'Administrador' },
  { id: 'u2', nome: 'João Lima', email: 'joao@exemplo.com', perfil: 'Vendedor' },
];
