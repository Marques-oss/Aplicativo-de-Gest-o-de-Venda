import { Alert, Platform } from 'react-native';

// Volta para a tela anterior; se não houver (ex.: página recarregada na web),
// vai para a rota padrão informada.
export function voltar(router, rotaPadrao) {
  if (router.canGoBack()) {
    router.back();
  } else {
    router.replace(rotaPadrao);
  }
}

// Pede confirmação antes de uma ação (ex.: excluir).
// No celular usa Alert; na web, Alert não tem botões, então usa window.confirm.
export function confirmar(titulo, mensagem, aoConfirmar, textoConfirmar = 'Excluir') {
  if (Platform.OS === 'web') {
    if (typeof window !== 'undefined' && window.confirm(`${titulo}\n\n${mensagem}`)) {
      aoConfirmar();
    }
    return;
  }

  Alert.alert(titulo, mensagem, [
    { text: 'Cancelar', style: 'cancel' },
    { text: textoConfirmar, style: 'destructive', onPress: aoConfirmar },
  ]);
}
