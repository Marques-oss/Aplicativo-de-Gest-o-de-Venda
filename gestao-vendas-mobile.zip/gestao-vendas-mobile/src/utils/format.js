// Formatação de textos. Feita "na mão" para funcionar igual em qualquer aparelho.

const doisDigitos = (n) => String(n).padStart(2, '0');

// 1234.5 -> "R$ 1.234,50"
export function formatarMoeda(valor) {
  const numero = Number(valor) || 0;
  const negativo = numero < 0;
  const centavos = Math.round(Math.abs(numero) * 100);
  const inteiro = Math.floor(centavos / 100);
  const decimais = doisDigitos(centavos % 100);
  const comMilhar = String(inteiro).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  return `${negativo ? '-' : ''}R$ ${comMilhar},${decimais}`;
}

// "2026-10-27T19:15:00.000Z" -> "27/10/2026 15:15" (no fuso do aparelho)
export function formatarDataHora(iso) {
  const data = new Date(iso);
  if (Number.isNaN(data.getTime())) return '-';
  return (
    `${doisDigitos(data.getDate())}/${doisDigitos(data.getMonth() + 1)}/${data.getFullYear()} ` +
    `${doisDigitos(data.getHours())}:${doisDigitos(data.getMinutes())}`
  );
}

// 18.9 -> "18,90" (para preencher o campo de preço na edição)
export function precoParaTexto(valor) {
  return Number(valor).toFixed(2).replace('.', ',');
}

// "Maria Souza" -> "MS"
export function iniciais(nome) {
  const partes = String(nome).trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '?';
  if (partes.length === 1) return partes[0].charAt(0).toUpperCase();
  return (partes[0].charAt(0) + partes[partes.length - 1].charAt(0)).toUpperCase();
}
