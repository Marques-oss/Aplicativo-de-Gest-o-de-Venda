// Funções de cálculo (sem nada de tela). Ficam separadas para poderem ser testadas.
//
// Dinheiro em ponto flutuante dá erros pequenos (0.1 + 0.2 = 0.30000000000000004).
// Por isso os cálculos são feitos em CENTAVOS (números inteiros) e só no fim
// dividimos por 100.

export function paraCentavos(valor) {
  return Math.round(Number(valor) * 100);
}

// preço × quantidade
export function calcularSubtotal(precoUnitario, quantidade) {
  return (paraCentavos(precoUnitario) * Number(quantidade)) / 100;
}

// Soma de todos os itens. Cada item: { precoUnitario, quantidade }
export function calcularTotal(itens) {
  const centavos = itens.reduce(
    (soma, item) => soma + paraCentavos(item.precoUnitario) * Number(item.quantidade),
    0
  );
  return centavos / 100;
}

// Indicadores gerais calculados a partir da lista de vendas registradas.
export function resumoVendas(vendas) {
  const quantidadeVendas = vendas.length;
  const centavos = vendas.reduce((soma, venda) => soma + paraCentavos(venda.total), 0);
  const itensVendidos = vendas.reduce(
    (soma, venda) => soma + venda.itens.reduce((s, item) => s + item.quantidade, 0),
    0
  );
  const ticketMedio = quantidadeVendas > 0 ? Math.round(centavos / quantidadeVendas) / 100 : 0;

  return {
    quantidadeVendas,
    valorTotal: centavos / 100,
    itensVendidos,
    ticketMedio,
  };
}

// Ranking de produtos. criterio: 'quantidade' (padrão) ou 'valor'.
export function produtosMaisVendidos(vendas, criterio = 'quantidade') {
  const mapa = new Map();

  for (const venda of vendas) {
    for (const item of venda.itens) {
      const atual = mapa.get(item.produtoId) || {
        produtoId: item.produtoId,
        nome: item.nome,
        quantidade: 0,
        centavos: 0,
      };
      atual.quantidade += item.quantidade;
      atual.centavos += paraCentavos(item.subtotal);
      mapa.set(item.produtoId, atual);
    }
  }

  const lista = Array.from(mapa.values()).map((p) => ({
    produtoId: p.produtoId,
    nome: p.nome,
    quantidade: p.quantidade,
    valor: p.centavos / 100,
  }));

  lista.sort((a, b) =>
    criterio === 'valor'
      ? b.valor - a.valor || b.quantidade - a.quantidade
      : b.quantidade - a.quantidade || b.valor - a.valor
  );

  return lista;
}
