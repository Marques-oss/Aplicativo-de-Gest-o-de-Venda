// Regras de validação dos formulários. Nada aqui depende de tela.

export const PERFIS = ['Administrador', 'Vendedor'];

// "18,90" -> 18.9 | "1.234,56" -> 1234.56 | "abc" -> NaN
export function converterPreco(texto) {
  const limpo = String(texto ?? '')
    .trim()
    .replace(/\s/g, '')
    .replace(/R\$/i, '');
  if (limpo === '') return NaN;

  let normal = limpo;
  if (limpo.includes(',')) {
    // formato brasileiro: ponto separa milhar, vírgula separa decimais
    normal = limpo.replace(/\./g, '').replace(',', '.');
  }
  if (!/^-?\d+(\.\d+)?$/.test(normal)) return NaN;
  return Number(normal);
}

// "10" -> 10 | "1.5" -> NaN | "abc" -> NaN
export function converterInteiro(texto) {
  const limpo = String(texto ?? '').trim();
  if (!/^-?\d+$/.test(limpo)) return NaN;
  return Number(limpo);
}

// Retorna { valido, erros: { campo: 'mensagem' }, valores }
export function validarProduto(campos, produtosExistentes, idAtual) {
  const erros = {};
  const nome = String(campos.nome ?? '').trim();
  const codigo = String(campos.codigo ?? '').trim();
  const categoria = String(campos.categoria ?? '').trim();
  const preco = converterPreco(campos.preco);
  const estoque = converterInteiro(campos.estoque);

  if (!nome) erros.nome = 'Informe o nome do produto.';

  if (!codigo) {
    erros.codigo = 'Informe o código do produto.';
  } else {
    const repetido = produtosExistentes.some(
      (p) => p.id !== idAtual && p.codigo.trim().toLowerCase() === codigo.toLowerCase()
    );
    if (repetido) erros.codigo = 'Já existe um produto com este código.';
  }

  if (!categoria) erros.categoria = 'Informe a categoria.';

  if (Number.isNaN(preco)) {
    erros.preco = 'Informe um preço válido (ex.: 18,90).';
  } else if (preco < 0) {
    erros.preco = 'O preço não pode ser negativo.';
  } else if (preco === 0) {
    erros.preco = 'O preço deve ser maior que zero.';
  } else if (Math.abs(preco * 100 - Math.round(preco * 100)) > 1e-6) {
    erros.preco = 'Use no máximo 2 casas decimais.';
  }

  if (Number.isNaN(estoque)) {
    erros.estoque = 'Informe uma quantidade inteira (ex.: 10).';
  } else if (estoque < 0) {
    erros.estoque = 'A quantidade não pode ser negativa.';
  }

  return {
    valido: Object.keys(erros).length === 0,
    erros,
    valores: { nome, codigo, categoria, preco, estoque },
  };
}

const REGEX_EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validarUsuario(campos, usuariosExistentes, idAtual) {
  const erros = {};
  const nome = String(campos.nome ?? '').trim();
  const email = String(campos.email ?? '').trim();
  const perfil = campos.perfil;

  if (!nome) erros.nome = 'Informe o nome do usuário.';

  if (!email) {
    erros.email = 'Informe o e-mail.';
  } else if (!REGEX_EMAIL.test(email)) {
    erros.email = 'E-mail inválido (ex.: nome@exemplo.com).';
  } else {
    const repetido = usuariosExistentes.some(
      (u) => u.id !== idAtual && u.email.trim().toLowerCase() === email.toLowerCase()
    );
    if (repetido) erros.email = 'Já existe um usuário com este e-mail.';
  }

  if (!PERFIS.includes(perfil)) erros.perfil = 'Escolha um perfil.';

  return {
    valido: Object.keys(erros).length === 0,
    erros,
    valores: { nome, email, perfil },
  };
}

// Valida a quantidade digitada numa venda. Retorna { ok, valor, erro }
export function validarQuantidadeVenda(texto, estoqueDisponivel) {
  const valor = converterInteiro(texto);

  if (Number.isNaN(valor)) {
    return { ok: false, valor, erro: 'Digite um número inteiro (ex.: 2).' };
  }
  if (valor <= 0) {
    return { ok: false, valor, erro: 'A quantidade deve ser maior que zero.' };
  }
  if (valor > estoqueDisponivel) {
    return {
      ok: false,
      valor,
      erro: `Estoque insuficiente. Disponível: ${estoqueDisponivel}.`,
    };
  }
  return { ok: true, valor, erro: null };
}
