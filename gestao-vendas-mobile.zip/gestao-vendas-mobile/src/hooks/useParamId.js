import { useLocalSearchParams } from 'expo-router';

// Lê o parâmetro "id" da rota (ex.: /produtos/p1 ou /produtos/form?id=p1).
export default function useParamId() {
  const { id } = useLocalSearchParams();
  return Array.isArray(id) ? id[0] : id;
}
