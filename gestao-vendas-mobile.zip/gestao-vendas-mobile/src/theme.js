// Cores, espaçamentos e tamanhos usados em todo o app.
// Mudar aqui muda o visual de todas as telas.

export const colors = {
  primaria: '#4338CA',
  primariaClara: '#E0E7FF',
  fundo: '#F3F4F8',
  superficie: '#FFFFFF',
  texto: '#111827',
  textoSuave: '#4B5563',
  placeholder: '#6B7280',
  borda: '#D1D5DB',
  perigo: '#B91C1C',
  perigoClaro: '#FEE2E2',
  sucesso: '#047857',
  sucessoClaro: '#D1FAE5',
  aviso: '#B45309',
  avisoClaro: '#FEF3C7',
};

export const spacing = { xs: 4, sm: 8, md: 16, lg: 24, xl: 32 };

export const radius = { sm: 8, md: 12, lg: 16 };

export const fonts = { pequena: 14, normal: 16, subtitulo: 18, titulo: 22, grande: 28 };

export const sombra = {
  shadowColor: '#000000',
  shadowOpacity: 0.06,
  shadowRadius: 6,
  shadowOffset: { width: 0, height: 2 },
  elevation: 2,
};
